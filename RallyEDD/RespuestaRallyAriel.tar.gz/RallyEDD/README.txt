Merino Peña Kevin Ariel
317031326	

Se puede correr todo el código con el Jar que esta en la carpeta src
Saludos
