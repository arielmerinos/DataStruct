Kevin Ariel Merino Peña
317031326

¿Es una buena práctica enviar excepciones en los métodos que puedan recibir nulos?
